/*
package com.transfer.excel2mysql.service;

import com.transfer.excel2mysql.domain.Employees;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

class ExcelUploadServiceTest {

    @Test
    void getEmployeesDataFromExcel() throws FileNotFoundException {
        File ff= new File("C:\\Users\\USER\\Downloads\\Classeur1.xlsx");
        FileInputStream file = new FileInputStream(ff);
        List<Employees> employees = null;
        employees = ExcelUploadService.getEmployeesDataFromExcel(file);
    }
}

*/