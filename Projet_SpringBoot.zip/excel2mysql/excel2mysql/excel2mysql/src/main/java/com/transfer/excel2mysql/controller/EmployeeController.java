package com.transfer.excel2mysql.controller;
import com.transfer.excel2mysql.domain.Employees;
import com.transfer.excel2mysql.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;
@RestController
@AllArgsConstructor
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/upload-data")
    public ResponseEntity<?> uploadEmployeesData(@RequestParam("file") MultipartFile file) throws IOException {
        this.employeeService.saveEmployeesToDatabase(file);
        return ResponseEntity
                .ok(Map.of("Message" , " Employees data uploaded and saved to database successfully"));
    }
    @GetMapping("/employees")
    public ResponseEntity<List<Employees>> getEmployees() throws FileNotFoundException {
        return new ResponseEntity<>(employeeService.getEmployees(), HttpStatus.FOUND);
    }
}
