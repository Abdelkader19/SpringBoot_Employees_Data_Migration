package com.transfer.excel2mysql.service;

import com.transfer.excel2mysql.domain.Employees;
import com.transfer.excel2mysql.repository.EmployeesRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
@Service
@AllArgsConstructor
public class EmployeeService {
    @Autowired
    private EmployeesRepository employeesRepository;
    @Autowired
    private ExcelUploadService excelUploadService;
/*
    public static void setEmployeesRepository(EmployeesRepository employeesRepository) {
        EmployeeService.employeesRepository = employeesRepository;
    }*/

    /*public void saveEmployeesToDatabase(MultipartFile file) {
        if (ExcelUploadService.isValidExcelFile(file)) {
            try {
                List<employees> employees = ExcelUploadService.getEmployeesDataFromExcel(file.getInputStream());
                employeesRepository.saveAll(employees);
            } catch (IOException e) {
                throw new IllegalArgumentException("The file is not a valid excel file");
            }
        }
    }*/

    public void saveEmployeesToDatabase(MultipartFile file) throws IOException {
            List<Employees> employees = excelUploadService.getEmployeesDataFromExcel(file.getInputStream());
            System.out.println(employees);
            employeesRepository.saveAll(employees);

    }
    public List<Employees> getEmployees() throws FileNotFoundException {
        File ff = new File("C:\\Users\\USER\\Desktop\\Classeur1.xlsx");
        FileInputStream file = new FileInputStream(ff);
        List<Employees> employees = null;
        employees = excelUploadService.getEmployeesDataFromExcel(file);
        //return employeesRepository.findAll();
        return employees;
    }
}

