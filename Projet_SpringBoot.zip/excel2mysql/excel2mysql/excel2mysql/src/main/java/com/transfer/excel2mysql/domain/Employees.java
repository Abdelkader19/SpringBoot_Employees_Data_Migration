package com.transfer.excel2mysql.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employees {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id",unique=true, nullable = false)
    private long id;
    private String departement;
    private String team;
    private String name ;
    private String jobtitle ;
    private String employmentDate;
    private String employementType ;
    private String grade ;
    private Integer lastEvaluationNote;
    private Integer evaluationNote;
    private String reviewPeriod;
    private String reviewerName;
    private String jobOffers;
    private String technicaOffers;
    private String lyo;
    private String aly;
    private String tny;
    private String ktts;
    private String rp;
    private String sdt;
    private Integer ta;
    private Integer workload;
    private Integer css;
    private Integer stl;
    private Integer stleader;
    private Integer sp;
    private Integer gl;
    private Integer tb;
    private Integer cp;
    private Integer csa;
    private Integer totsc;
    private Integer tkeTl;
    private Integer qwTl;
    private Integer paTl;
    private Integer ssTl;
    private Integer drpTl;
    private Integer tkeD;
    private Integer qwD;
    private Integer paD;
    private Integer ssD;
    private Integer drpD;
    private Integer totscTl;
    private Integer totscD;
    private String psfu;
    private String tp;
    private String ort;
    private Integer si;
    private String grade2;
    private Integer accSc;
    private Integer scToNxtGrd;
    private String satisfGrd;
}