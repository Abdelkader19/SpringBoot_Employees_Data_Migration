package com.transfer.excel2mysql.service;

import com.transfer.excel2mysql.domain.Employees;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
@Service
public class ExcelUploadService {
    public static boolean isValidExcelFile(MultipartFile file){
        return Objects.equals(file.getContentType(),"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

    }
    public static List<Employees> getEmployeesDataFromExcel(InputStream inputStream) throws FileNotFoundException {
        //File ff= new File("C:\\Users\\fares\\Downloads\\Classeur1.xlsx");
        //FileInputStream inputStream = new FileInputStream(ff);
        List<Employees> employees = new ArrayList<>();
        try {
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = workbook.getSheet("employees");
            int rowIndex =0;
            for (Row row : sheet){
                if (rowIndex ==0){
                    rowIndex++;
                    continue;
                }
                Iterator<Cell> cellIterator = row.iterator();
                int cellIndex = 0;
                Employees employee = new Employees();
                while (cellIterator.hasNext()){
                    Cell cell = cellIterator.next();
                    switch (cellIndex){
                        case 0 -> employee.setDepartement(cell.getStringCellValue());
                        case 1 -> employee.setTeam(cell.getStringCellValue());
                        case 2 -> employee.setName(cell.getStringCellValue());
                        case 3 -> employee.setJobtitle(cell.getStringCellValue());
                        case 4 -> employee.setEmploymentDate(cell.getStringCellValue());
                        case 5 -> employee.setEmployementType(cell.getStringCellValue());
                        case 6 -> employee.setGrade(cell.getStringCellValue());
                        case 7 -> employee.setLastEvaluationNote((int)cell.getNumericCellValue());
                        case 8 -> employee.setEvaluationNote((int)cell.getNumericCellValue());
                        case 9 -> employee.setReviewPeriod(cell.getStringCellValue());
                        case 10 -> employee.setReviewerName(cell.getStringCellValue());
                        case 11 -> employee.setJobOffers(cell.getStringCellValue());
                        case 12 -> employee.setTechnicaOffers(cell.getStringCellValue());
                        case 13 -> employee.setLyo(cell.getStringCellValue());
                        case 14 -> employee.setAly(cell.getStringCellValue());
                        case 15 -> employee.setTny(cell.getStringCellValue());
                        case 16 -> employee.setKtts(cell.getStringCellValue());
                        case 17 -> employee.setRp(cell.getStringCellValue());
                        case 18 -> employee.setSdt(cell.getStringCellValue());
                        case 19 -> employee.setTa((int)cell.getNumericCellValue());
                        case 20 -> employee.setWorkload((int)cell.getNumericCellValue());
                        case 21 -> employee.setCss((int)cell.getNumericCellValue());
                        case 22 -> employee.setStl((int)cell.getNumericCellValue());
                        case 23 -> employee.setStleader((int)cell.getNumericCellValue());
                        case 24 -> employee.setSp((int)cell.getNumericCellValue());
                        case 25 -> employee.setGl((int)cell.getNumericCellValue());
                        case 26 -> employee.setTb((int)cell.getNumericCellValue());
                        case 27 -> employee.setCp((int)cell.getNumericCellValue());
                        case 28 -> employee.setCsa((int)cell.getNumericCellValue());
                        case 29 -> employee.setTotsc((int)cell.getNumericCellValue());
                        case 30 -> employee.setTkeTl((int)cell.getNumericCellValue());
                        case 31 -> employee.setQwTl((int)cell.getNumericCellValue());
                        case 32 -> employee.setPaTl((int)cell.getNumericCellValue());
                        case 33 -> employee.setSsTl((int)cell.getNumericCellValue());
                        case 34 -> employee.setDrpTl((int)cell.getNumericCellValue());
                        case 35 -> employee.setTkeD((int)cell.getNumericCellValue());
                        case 36 -> employee.setQwD((int)cell.getNumericCellValue());
                        case 37 -> employee.setPaD((int)cell.getNumericCellValue());
                        case 38 -> employee.setSsD((int)cell.getNumericCellValue());
                        case 39 -> employee.setDrpD((int)cell.getNumericCellValue());
                        case 40 -> employee.setTotscTl((int)cell.getNumericCellValue());
                        case 41 -> employee.setTotscD((int)cell.getNumericCellValue());
                        case 42 -> employee.setPsfu(cell.getStringCellValue());
                        case 43 -> employee.setTp(cell.getStringCellValue());
                        case 44 -> employee.setOrt(cell.getStringCellValue());
                        case 45 -> employee.setSi((int)cell.getNumericCellValue());
                        case 46 -> employee.setGrade2(cell.getStringCellValue());
                        case 47 -> employee.setAccSc((int)cell.getNumericCellValue());
                        case 48 -> employee.setScToNxtGrd((int)cell.getNumericCellValue());
                        case 49 -> employee.setSatisfGrd(cell.getStringCellValue());


                        default -> {
                        }
                    }
                    cellIndex++;
                }
                employees.add(employee);
                //System.out.println(employees.get(0));
            }
        } catch (IOException e) {
            e.getStackTrace();
        }
        return employees;
    }

}
