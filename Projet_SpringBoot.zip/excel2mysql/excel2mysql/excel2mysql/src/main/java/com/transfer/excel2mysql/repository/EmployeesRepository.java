package com.transfer.excel2mysql.repository;

import com.transfer.excel2mysql.domain.Employees;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeesRepository extends JpaRepository<Employees,String> {

}
